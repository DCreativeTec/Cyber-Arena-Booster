# Cyber//Arena Booster v1.1

Original Android performance HUD inspired by the visual language of gaming overlays. Not affiliated with Infinix/XArena.

## Features
- Cyberpunk/XArena-style HUD
- Floating, draggable overlay with compact mode
- FPS estimation from `dumpsys gfxinfo` frame deltas when Shizuku permits access
- CPU, GPU load (device/kernel dependent), RAM, thermal, battery, and network ping
- Per-game profiles for Free Fire, Mobile Legends, Roblox, and Clash of Clans
- Shizuku-first boost commands; root is optional
- Usage access for foreground-game detection
- DND and brightness quick-access controls
- Android 15 / target SDK 35

## Important limitations
Android does not grant ordinary third-party apps a universal live FPS API for arbitrary games. This app therefore uses a best-effort `gfxinfo` frame-delta estimate through Shizuku. GPU telemetry is kernel/OEM dependent and may show `--`.

The Boost button sends conservative Android game-mode commands when supported. It does not magically overclock the SoC, unlock hidden FPS, or bypass OEM thermal limits.

Screen recording is intentionally left to Android's system MediaProjection/Quick Settings flow rather than attempting a silent capture.

## Build
Open the `cyberarena` directory in Android Studio, or run the included GitHub Actions workflow. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions
Grant overlay permission, Usage Access, and Shizuku permission as needed. DND/brightness controls open the corresponding Android settings because those permissions require explicit user approval.
