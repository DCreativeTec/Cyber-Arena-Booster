package com.cyberarena.booster;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.Typeface;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity{
    LinearLayout root,stats; TextView shizuku; Handler h=new Handler(Looper.getMainLooper());
    String[] games={"Free Fire","Mobile Legends","Roblox","Clash of Clans"}; String[] pkgs={"com.dts.freefireth","com.mobile.legends","com.roblox.client","com.supercell.clashofclans"}; int selected=0;
    int cyan=Color.rgb(0,229,255),pink=Color.rgb(255,43,214),white=Color.rgb(245,247,250),muted=Color.rgb(131,144,163),lime=Color.rgb(184,255,61);
    @Override public void onCreate(Bundle b){super.onCreate(b);build();refresh();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(white);t.setTextSize(sp);t.setTypeface(Typeface.create("sans",Typeface.BOLD));t.setPadding(14,8,14,8);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setTextSize(11);b.setAllCaps(false);b.setBackgroundColor(Color.rgb(18,25,36));return b;}
    void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,16,18,16);root.setBackgroundColor(Color.rgb(5,7,11)); ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        TextView title=tv("CYBER//ARENA",29);title.setTextColor(cyan);body.addView(title);body.addView(tv("XOS 15 • PERFORMANCE CONSOLE • v1.1",11));
        shizuku=tv("● SHIZUKU: checking...",13);shizuku.setTextColor(pink);body.addView(shizuku);
        TextView gp=tv("GAME PROFILE",12);gp.setTextColor(cyan);body.addView(gp);LinearLayout row=new LinearLayout(this);for(int i=0;i<games.length;i++){final int k=i;Button b=btn(games[i]);b.setOnClickListener(v->{selected=k;refresh();});row.addView(b,new LinearLayout.LayoutParams(0,62,1));}body.addView(row);
        stats=new LinearLayout(this);stats.setOrientation(LinearLayout.VERTICAL);body.addView(stats);
        TextView ac=tv("QUICK ACTIONS",12);ac.setTextColor(cyan);body.addView(ac);LinearLayout a1=new LinearLayout(this);Button boost=btn("⚡ BOOST");boost.setTextColor(lime);boost.setOnClickListener(v->boost());Button overlay=btn("◈ OVERLAY");overlay.setTextColor(cyan);overlay.setOnClickListener(v->startOverlay());a1.addView(boost,new LinearLayout.LayoutParams(0,64,1));a1.addView(overlay,new LinearLayout.LayoutParams(0,64,1));body.addView(a1);
        LinearLayout a2=new LinearLayout(this);Button usage=btn("◉ USAGE ACCESS");usage.setOnClickListener(v->usage());Button dnd=btn("☾ DND");dnd.setOnClickListener(v->dnd());Button bright=btn("☼ BRIGHT");bright.setOnClickListener(v->brightness());a2.addView(usage,new LinearLayout.LayoutParams(0,64,1));a2.addView(dnd,new LinearLayout.LayoutParams(0,64,1));a2.addView(bright,new LinearLayout.LayoutParams(0,64,1));body.addView(a2);
        Button record=btn("⏺  SCREEN RECORDING");record.setOnClickListener(v->toast("Screen recording memakai system MediaProjection; jalankan dari Quick Settings untuk hasil paling stabil."));body.addView(record,new LinearLayout.LayoutParams(-1,64));
        Button access=btn("⚙ PERMISSIONS / SHIZUKU");access.setOnClickListener(v->access());body.addView(access,new LinearLayout.LayoutParams(-1,64));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void refresh(){h.post(()->{if(Shell.available()){shizuku.setText("● SHIZUKU: ONLINE");shizuku.setTextColor(lime);}else{shizuku.setText("● SHIZUKU: OFFLINE — grant access");shizuku.setTextColor(pink);}stats.removeAllViews();addStat("FPS (estimated)",Telemetry.fps(pkgs[selected]));addStat("PING",Telemetry.ping());addStat("CPU",Telemetry.cpu());addStat("GPU",Telemetry.gpu());addStat("RAM",Telemetry.ram(this));addStat("TEMP",Telemetry.temp());addStat("BATTERY",Telemetry.battery(this)+"%");h.postDelayed(this::refresh,2500);});}
    void addStat(String a,String b){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView l=tv(a,12);l.setTextColor(muted);TextView v=tv(b,18);v.setTextColor(cyan);r.addView(l,new LinearLayout.LayoutParams(0,58,1));r.addView(v);stats.addView(r);}
    void boost(){if(!Shell.available()){toast("Aktifkan Shizuku dulu");return;}String p=pkgs[selected];Shell.run("cmd game mode performance "+p+" 2>/dev/null; am set-inactive "+p+" false 2>/dev/null");toast("Boost command dikirim untuk "+games[selected]);}
    void startOverlay(){if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}startForegroundService(new Intent(this,OverlayService.class));toast("HUD overlay aktif");}
    void access(){if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}toast("Grant permission aplikasi ini dari Shizuku Manager");}
    void usage(){startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));}
    void dnd(){try{startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));}catch(Exception e){toast("Menu DND tidak tersedia");}}
    void brightness(){try{startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception e){toast("Izin brightness tidak tersedia");}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
