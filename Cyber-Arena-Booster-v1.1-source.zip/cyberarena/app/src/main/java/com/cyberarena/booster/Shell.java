package com.cyberarena.booster;

import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import rikka.shizuku.Shizuku;

public final class Shell {
    public static boolean available(){ try { return Shizuku.pingBinder() && Shizuku.checkSelfPermission()==0; } catch(Throwable t){ return false; } }
    public static String run(String command){
        if(!available()) return "";
        try {
            Method m=Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Object p=m.invoke(null,new String[]{"sh","-c",command},null,null);
            InputStream in=(InputStream)p.getClass().getMethod("getInputStream").invoke(p);
            InputStream err=(InputStream)p.getClass().getMethod("getErrorStream").invoke(p);
            String out=new String(in.readAllBytes(),StandardCharsets.UTF_8);
            try{p.getClass().getMethod("destroy").invoke(p);}catch(Throwable ignored){}
            return out.trim();
        } catch(Throwable t){ return ""; }
    }
    private Shell(){}
}
