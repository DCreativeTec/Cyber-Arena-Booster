package com.cyberarena.booster;

import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;

public final class GameDetector {
    public static String foreground(Context c){
        try{
            UsageStatsManager usm=(UsageStatsManager)c.getSystemService(Context.USAGE_STATS_SERVICE);
            long end=System.currentTimeMillis(), start=end-15000;
            UsageEvents e=usm.queryEvents(start,end); UsageEvents.Event ev=new UsageEvents.Event(); String last=null;
            while(e.hasNextEvent()){e.getNextEvent(ev); if(ev.getEventType()==UsageEvents.Event.MOVE_TO_FOREGROUND) last=ev.getPackageName();}
            return last;
        }catch(Exception ex){return null;}
    }
    private GameDetector(){}
}
