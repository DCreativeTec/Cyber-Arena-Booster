package com.cyberarena.booster;

import android.app.ActivityManager;
import android.content.Context;
import android.os.BatteryManager;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Telemetry {
    private static long lastFrames = -1, lastFrameTime = -1;
    public static synchronized String fps(String pkg){
        if(pkg==null||pkg.isEmpty()||!Shell.available()) return "--";
        String s=Shell.run("dumpsys gfxinfo " + safe(pkg) + " | grep -m1 'Total frames rendered'");
        Matcher m=Pattern.compile("(\\d+)\\s*$").matcher(s);
        if(!m.find()) return "--";
        long frames=Long.parseLong(m.group(1)); long now=System.currentTimeMillis();
        if(lastFrames>=0 && lastFrameTime>0){ long df=Math.max(0,frames-lastFrames); long dt=Math.max(1,now-lastFrameTime); lastFrames=frames; lastFrameTime=now; return String.format(Locale.US,"%.0f",df*1000.0/dt); }
        lastFrames=frames; lastFrameTime=now; return "--";
    }
    public static String ram(Context c){ ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); ((ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(m); long used=m.totalMem-m.availMem; return fmt(used)+" / "+fmt(m.totalMem); }
    public static int battery(Context c){ BatteryManager b=(BatteryManager)c.getSystemService(Context.BATTERY_SERVICE); return b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); }
    public static String cpu(){ String s=Shell.run("dumpsys cpuinfo | grep -m1 'TOTAL:'"); Matcher m=Pattern.compile("TOTAL:\\s*([0-9.]+)%").matcher(s); return m.find()?m.group(1)+"%":"--"; }
    public static String temp(){ String s=Shell.run("for f in /sys/class/thermal/thermal_zone*/temp; do [ -r \"$f\" ] && cat \"$f\"; done"); double max=-1; for(String x:s.split("\\s+")) try{double v=Double.parseDouble(x); if(v>1000)v/=1000; if(v>20&&v<120)max=Math.max(max,v);}catch(Exception ignored){} return max<0?"--":String.format(Locale.US,"%.1f°C",max); }
    public static String gpu(){ String s=Shell.run("for f in /sys/class/misc/mali0/device/gpu_busy /sys/class/misc/mali0/device/gpu_busy_percent /sys/class/devfreq/*gpu*/load /sys/class/devfreq/*mali*/load; do [ -r \"$f\" ] && { cat \"$f\"; break; }; done"); Matcher m=Pattern.compile("(\\d{1,3})").matcher(s); return m.find()?m.group(1)+"%":"--"; }
    public static String ping(){ String s=Shell.run("ping -c 1 -W 1 1.1.1.1 2>/dev/null"); Matcher m=Pattern.compile("time[=<]([0-9.]+)\\s*ms").matcher(s); return m.find()?m.group(1)+" ms":"--"; }
    private static String safe(String p){return p.replaceAll("[^a-zA-Z0-9._]","");}
    private static String fmt(long b){return String.format(Locale.US,"%.1f GB",b/1073741824.0);}
    private Telemetry(){}
}
